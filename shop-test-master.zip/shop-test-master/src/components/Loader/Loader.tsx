import React from "react"
export const Loader = () => {
    return (
        <p>Loadig...</p>
    )
}